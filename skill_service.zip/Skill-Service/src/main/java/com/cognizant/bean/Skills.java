package com.cognizant.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Skills {
	@Id
	Long id;
	@NotBlank(message="name cannot be blank")
	String name;
	@NotBlank(message="It cannot be blank")
	String description;
	@NotBlank(message="it cannot be blank")
	String level;
	@NotNull
	Long user_id;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Long getUser_id() {
		return user_id;
	}
	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	@Override
	public String toString() {
		return "Skills [id=" + id + ", name=" + name + ", description=" + description + ", level=" + level
				+ ", user_id=" + user_id + "]";
	}
	
}
